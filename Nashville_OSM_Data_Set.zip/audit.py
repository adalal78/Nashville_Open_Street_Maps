
# coding: utf-8

# In[ ]:

import csv
import codecs
import pprint
import re
import xml.etree.cElementTree as ET
from collections import defaultdict
from geopy.geocoders import Nominatim
geolocator = Nominatim()
from time import sleep
import schema

def count_tags(filename):
        # YOUR CODE HERE
        tree = ET.parse(filename)
        root = tree.getroot()
        #print root.tag
        tag_dict = {}
        for child in tree.iter():
            #print child.tag
            if (child.tag in tag_dict.keys()):
                tag_dict[child.tag] += 1
            else:
                if (child.tag != 'None'):
                    tag_dict[child.tag] = 1
        
        return tag_dict
    
def count_child_of_root(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    tag_dict = {}
    for child in root:
        if (child.tag in tag_dict.keys()):
            tag_dict[child.tag] += 1
        else:
            if (child.tag != 'None'):
                tag_dict[child.tag] = 1
    return tag_dict


#See relation tag
def relation_tag(filename):
    tree = ET.parse(filename)
    for node in tree.iter():
        if (node.tag == 'relation'):
            pprint.pprint(node.attrib)

#Obtain the k and v values of all tags <tag>
def kv_values(filename):
    tree = ET.parse(filename)
    #k_set = set()
    #v_set = set()
    kv_dict = {}
    for child in tree.iter():
        if (child.tag == 'tag'):
            #k_set.add(child.attrib['k'])
            #v_set.add(child.attrib['v'])
            kv_dict[child.attrib['k']] = child.attrib['v']
            #print child['k']
            #print child['v']
            #print ""
    return kv_dict

#My audit of street types
def my_audit_street_type(street_types, street_name):
    expected = ["Street", "Avenue", "Boulevard", "Drive", "Court", "Place", "Square", "Lane", "Road", "Trail", "Parkway", "Commons"]
    street_type_re = re.compile(r'\b\S+\.?$', re.IGNORECASE)
    m = street_type_re.search(street_name)
    if m:
        street_type = m.group()
        if street_type not in expected:
            street_types[street_type].add(street_name)

#audit osm file
def audit(osmfile):
    osm_file = open(osmfile, "r")
    street_types = defaultdict(set)
    
    for event, elem in ET.iterparse(osm_file, events=("start",)):

        if elem.tag == "node" or elem.tag == "way":
            for tag in elem.iter("tag"):
                if (tag.attrib['k'] == "addr:street"):
                    #audit_street_type(street_types, tag.attrib['v'])
                    #print tag.attrib['k'], tag.attrib['v']
                    #print ""
                    my_audit_street_type(street_types, tag.attrib['v'])
                    
                    
    osm_file.close()
    return street_types

def my_audit(filename, search_tag):
    tree = ET.parse(filename)
    root = tree.getroot()
    city_dict = {}
    for child in tree.iter():
        #print child.tag
        if (child.tag == search_tag):
            #pprint.pprint(child.attrib)
            if ('addr:city' in child.attrib['k']):
                #pprint.pprint(child.attrib)
                #print ""
                v_val = child.attrib['v']
                if (v_val in city_dict.keys()):
                    city_dict[v_val] += 1
                else:
                    city_dict[v_val] = 1
                    
    return city_dict

def update_city_name(name):
    
    if (', TN' in name):
        name = name.replace(', TN', '')
        
    if (', Tennessee' in name):
        name = name.replace(', Tennessee', '')
        
    if (name == 'LaVergne'):
        name = 'La Vergne'
        
    if (name == 'Mount Joliet'):
        name = 'Mount Juliet'
        
    if (not name[0].isupper()):
        name = name.capitalize()
        
    if ( (name == 'Thompson"s Station') or (name == 'Thompsons Station') ):
        name = "Thompson's Station"
        
    return name

def update_name(name):
    mapping = { "Ave": "Avenue",
            "AVENUE": "Avenue",
            "ave": "Avenue",
            "avenue": "Avenue",
            "BLVD": "Boulevard",
            "Blvd": "Boulevard",
            "Cir": "Circle",
            "Ct": "Court",
            "Dr": "Drive",
            "hills": "Hills",
            "Hwy": "Highway",
            "Hwy.": "Highway",
            "Ln": "Lane",
            "pike": "Pike",
            "Pk": "Pike",
            "Pkwy": "Parkway",
            "Pky": "Parkway",
            "Rd.": "Road",
            "Rd": "Road",
            "S": "South",
            "St": "Street",
            "St.": "Street",
            "st": "Street",
            "W": "West"
            }
    for key in mapping.keys():
        if (name.endswith(key)):
            name = name.replace(' '+key, ' ' + mapping[key])
    
    return name

def node_to_postcode(filename):
    tree = ET.parse(filename)
    zipcode_dict = {}
    for tag in tree.iter('node'):
        if ('lon' in tag.attrib.keys() and 'lat' in tag.attrib.keys()):
            lat_lon_pair = [tag.attrib['lat'], tag.attrib['lon']]
            #lat_lon_pair = "lat_lon_pair"
            #print tag.attrib['lon'], tag.attrib['lat'], lat_lon_pair
            location = geolocator.reverse(lat_lon_pair, timeout= 10)
            #print location.raw
            #print ""
            if ('address' in location.raw.keys()):
                address_dict = location.raw['address']
                if ('postcode' in address_dict.keys()):
                    zipcode = address_dict['postcode']
                    #print zipcode
                    #print ""
                    if (zipcode not in zipcode_dict.keys()):
                        zipcode_dict[zipcode] = 1
                    else:
                        zipcode_dict[zipcode] += 1
                        
    return zipcode_dict

